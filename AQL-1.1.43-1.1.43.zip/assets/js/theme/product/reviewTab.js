// Add Review Tab
// const reviewTab = '<li><a href="#Reviews"</a></li>';
// document.querySelector('.tabNavigation').append(reviewTab);
