// Accessory Page JS
const accessoryTabContent = document.querySelector('#Things').innerText;

console.log(accessoryTabContent);
